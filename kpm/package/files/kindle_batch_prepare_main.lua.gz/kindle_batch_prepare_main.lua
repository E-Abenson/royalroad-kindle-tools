-- KOREADER_BATCH_PREPARE_MENU_FIX_V2
local DataStorage = require("datastorage")
local ffi = require("ffi")
local ffiUtil = require("ffi/util")
local lfs = require("libs/libkoreader-lfs")
local InfoMessage = require("ui/widget/infomessage")
local UIManager = require("ui/uimanager")
local Trapper = require("ui/trapper")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local json = require("json")
local util = require("util")
local logger = require("logger")
local _ = require("gettext")
local T = require("ffi/util").template

local KINDLE_PLUGIN_DIR = DataStorage:getFullDataDir() .. "/plugins/kindle.koplugin"
package.path = package.path .. ";" .. KINDLE_PLUGIN_DIR .. "/?.lua;" .. KINDLE_PLUGIN_DIR .. "/?/init.lua"

local HelperClient = require("lua/helper_client")
local LibraryIndex = require("lua/library_index")
local VirtualLibrary = require("lua/virtual_library")
local CacheManager = require("lua/cache_manager")

pcall(ffi.cdef, "int kill(int pid, int sig);")

local PATCH_MARKER = "# KOREADER_BATCH_PREPARE_V1"
local DEFAULT_MIN_FREE_MB = 512
local PLUGIN = WidgetContainer:extend({
    name = "kindle_batch_prepare",
    is_doc_only = false,
})

local function readFile(path)
    local f = io.open(path, "rb")
    if not f then return nil end
    local data = f:read("*a")
    f:close()
    return data
end

local function writeFile(path, data)
    local f, err = io.open(path, "wb")
    if not f then return nil, err end
    f:write(data)
    f:close()
    return true
end

local function replaceOnce(source, needle, replacement, label)
    local first, last = source:find(needle, 1, true)
    if not first then
        error("Could not locate expected Kindle helper code: " .. label)
    end
    local second = source:find(needle, last + 1, true)
    if second then
        error("Found more than one copy of expected Kindle helper code: " .. label)
    end
    return source:sub(1, first - 1) .. replacement .. source:sub(last + 1)
end

local PROGRESS_CLASS = [==[

# KOREADER_BATCH_PREPARE_V1
class BatchConversionCancelled(Exception):
    pass


class BatchLowStorageError(Exception):
    def __init__(self, free_bytes, required_bytes):
        self.free_bytes = int(free_bytes)
        self.required_bytes = int(required_bytes)
        super().__init__(
            "Low storage: %d MB free; at least %d MB must remain" %
            (self.free_bytes // (1024 * 1024), self.required_bytes // (1024 * 1024))
        )


class BatchConversionProgress:
    def __init__(self, args, output_path):
        self.progress_file = getattr(args, "progress_file", "") or ""
        self.cancel_file = getattr(args, "cancel_file", "") or ""
        self.min_free_bytes = max(0, int(getattr(args, "min_free_bytes", 0) or 0))
        self.cache_dir = getattr(args, "cache_dir", "") or os.path.dirname(os.path.abspath(output_path))
        self.output_path = output_path
        self.last_percent = -1
        self.last_written_percent = -1
        self.last_written_stage = None
        self.last_write_time = 0.0

    def install_signal_handlers(self):
        if not self.cancel_file:
            return

        def stop_handler(_signum, _frame):
            raise BatchConversionCancelled("Batch preparation cancelled")

        signal.signal(signal.SIGTERM, stop_handler)
        signal.signal(signal.SIGINT, stop_handler)

    def check_cancel(self):
        if self.cancel_file and os.path.exists(self.cancel_file):
            raise BatchConversionCancelled("Batch preparation cancelled")

    def check_storage(self, extra_bytes=0):
        if self.min_free_bytes <= 0:
            return None
        self.check_cancel()
        usage = shutil.disk_usage(self.cache_dir)
        required = self.min_free_bytes + max(0, int(extra_bytes or 0))
        if usage.free < required:
            raise BatchLowStorageError(usage.free, required)
        return usage.free

    def update(self, percent, stage, extra_bytes=0):
        self.check_cancel()
        free_bytes = self.check_storage(extra_bytes)
        percent = max(0.0, min(100.0, float(percent)))
        now = time.monotonic()
        stage = str(stage)
        should_write = (
            int(percent) != self.last_written_percent
            or stage != self.last_written_stage
            or now - self.last_write_time >= 0.75
            or percent >= 100
        )
        if self.progress_file and should_write:
            payload = {
                "percent": percent,
                "stage": stage,
                "free_bytes": free_bytes,
                "min_free_bytes": self.min_free_bytes,
            }
            temp_path = self.progress_file + ".tmp"
            os.makedirs(os.path.dirname(self.progress_file) or ".", exist_ok=True)
            with open(temp_path, "w", encoding="utf-8") as progress_file:
                json.dump(payload, progress_file)
                progress_file.flush()
                os.fsync(progress_file.fileno())
            os.replace(temp_path, self.progress_file)
            self.last_written_percent = int(percent)
            self.last_written_stage = stage
            self.last_write_time = now
        self.last_percent = percent

    def check(self, extra_bytes=0):
        self.check_cancel()
        self.check_storage(extra_bytes)

    def kfx_progress(self, percent):
        percent = float(percent)
        stage = "Reading Kindle book structure" if percent <= 10 else "Building EPUB"
        self.update(percent, stage)


]==]

local function patchPythonHelper()
    local helper_path = KINDLE_PLUGIN_DIR .. "/dist/kindle_helper.py"
    local source = readFile(helper_path)
    if not source then
        return nil, "Could not read " .. helper_path
    end
    if source:find(PATCH_MARKER, 1, true) then
        return false, "already_patched"
    end
    if not source:find("VERSION = 1", 1, true) or not source:find("def cmd_convert(args):", 1, true) then
        return nil, "The installed Kindle Library helper is not the expected v0.0.11 layout. No files were changed."
    end

    local ok, patched = pcall(function()
        local result = source
        result = replaceOnce(result, "import os\nimport re\n", "import os\nimport shutil\nimport signal\nimport time\nimport re\n", "imports")
        result = replaceOnce(
            result,
            "VERSION = 1\n\n# ---------------------------------------------------------------------------\n# JSON output helpers",
            "VERSION = 1" .. PROGRESS_CLASS .. "# ---------------------------------------------------------------------------\n# JSON output helpers",
            "progress support insertion"
        )

        local function_start = result:find("def cmd_convert(args):", 1, true)
        local function_end = result:find("# ---------------------------------------------------------------------------\n# CLI argument parsing", function_start, true)
        if not function_start or not function_end then
            error("Could not isolate cmd_convert()")
        end
        local fn = result:sub(function_start, function_end - 1)

        fn = replaceOnce(
            fn,
            '    cache_dir = getattr(args, "cache_dir", "") or ""\n\n    try:\n',
            '    cache_dir = getattr(args, "cache_dir", "") or ""\n'
                .. '    progress = BatchConversionProgress(args, output_path)\n\n'
                .. '    try:\n'
                .. '        progress.install_signal_handlers()\n'
                .. '        progress.update(1, "Starting conversion")\n',
            "conversion progress initialization"
        )
        fn = replaceOnce(
            fn,
            "        convert_path = input_path\n",
            "        convert_path = input_path\n        progress.update(5, \"Reading Kindle source\")\n",
            "source stage"
        )
        fn = replaceOnce(
            fn,
            '            with open(input_path, "rb") as f:\n                data = f.read()\n',
            '            progress.update(6, "Decrypting Kindle book", extra_bytes=os.path.getsize(input_path))\n'
                .. '            with open(input_path, "rb") as f:\n                data = f.read()\n',
            "decryption stage"
        )
        fn = replaceOnce(
            fn,
            '            tmp = tempfile.NamedTemporaryFile(suffix=".kfx-zip", delete=False)\n            try:\n',
            '            tmp = tempfile.NamedTemporaryFile(\n'
                .. '                suffix=".kfx-zip", delete=False,\n'
                .. '                dir=os.path.dirname(os.path.abspath(output_path)),\n'
                .. '                prefix=os.path.basename(output_path) + ".batch-source-"\n'
                .. '            )\n'
                .. '            convert_path = tmp.name\n'
                .. '            progress.update(7, "Assembling decrypted source", extra_bytes=len(cont_data))\n'
                .. '            try:\n',
            "temporary source tracking"
        )
        fn = replaceOnce(
            fn,
            '                                if blob.startswith(CONT_SIGNATURE):\n                                    zf.writestr(rel, blob)\n',
            '                                if blob.startswith(CONT_SIGNATURE):\n                                    progress.check(extra_bytes=len(blob))\n                                    zf.writestr(rel, blob)\n',
            "decrypted sidecar storage check"
        )
        fn = replaceOnce(
            fn,
            '        book = YJ_Book(convert_path)\n',
            '        progress.update(9, "Reading KFX structure")\n'
                .. '        book = YJ_Book(convert_path)\n',
            "book structure stage"
        )
        fn = replaceOnce(
            fn,
            '            epub_data = book.convert_to_epub(epub2_desired=False)\n',
            '            epub_data = book.convert_to_epub(\n'
                .. '                epub2_desired=False, progress_fn=progress.kfx_progress\n'
                .. '            )\n',
            "kfxlib progress callback"
        )
        fn = replaceOnce(
            fn,
            '        with open(output_path, "wb") as f:\n            f.write(epub_data)\n',
            '        progress.update(92, "Writing EPUB", extra_bytes=len(epub_data))\n'
                .. '        chunk_size = 1024 * 1024\n'
                .. '        total_bytes = len(epub_data)\n'
                .. '        written_bytes = 0\n'
                .. '        with open(output_path, "wb") as f:\n'
                .. '            for offset in range(0, total_bytes, chunk_size):\n'
                .. '                chunk = epub_data[offset:offset + chunk_size]\n'
                .. '                remaining = max(0, total_bytes - written_bytes)\n'
                .. '                progress.check(extra_bytes=remaining)\n'
                .. '                f.write(chunk)\n'
                .. '                written_bytes += len(chunk)\n'
                .. '                remaining = max(0, total_bytes - written_bytes)\n'
                .. '                progress.update(92 + (6 * written_bytes / max(1, total_bytes)), "Writing EPUB", extra_bytes=remaining)\n',
            "chunked EPUB writer"
        )
        fn = replaceOnce(
            fn,
            '        map_path = re.sub(r"\\.epub$", ".positions.json", output_path)\n        try:\n',
            '        map_path = re.sub(r"\\.epub$", ".positions.json", output_path)\n'
                .. '        progress.update(99, "Creating reading-position map", extra_bytes=8 * 1024 * 1024)\n'
                .. '        try:\n',
            "position map stage"
        )
        fn = replaceOnce(
            fn,
            '        exit_json({\n            "version": VERSION,\n            "ok": True,\n            "output_path": output_path,\n        })\n\n    except Exception as e:\n',
            '        progress.update(100, "Finished")\n'
                .. '        exit_json({\n            "version": VERSION,\n            "ok": True,\n            "output_path": output_path,\n        })\n\n'
                .. '    except BatchConversionCancelled as e:\n'
                .. '        for cleanup_path in (output_path, re.sub(r"\\.epub$", ".positions.json", output_path)):\n'
                .. '            try:\n                os.unlink(cleanup_path)\n            except OSError:\n                pass\n'
                .. '        if "convert_path" in locals() and convert_path != input_path:\n'
                .. '            try:\n                os.unlink(convert_path)\n            except OSError:\n                pass\n'
                .. '        exit_json({"version": VERSION, "ok": False, "code": "cancelled", "message": str(e)})\n\n'
                .. '    except BatchLowStorageError as e:\n'
                .. '        for cleanup_path in (output_path, re.sub(r"\\.epub$", ".positions.json", output_path)):\n'
                .. '            try:\n                os.unlink(cleanup_path)\n            except OSError:\n                pass\n'
                .. '        if "convert_path" in locals() and convert_path != input_path:\n'
                .. '            try:\n                os.unlink(convert_path)\n            except OSError:\n                pass\n'
                .. '        exit_json({"version": VERSION, "ok": False, "code": "low_storage", "message": str(e), "free_bytes": e.free_bytes, "required_bytes": e.required_bytes})\n\n'
                .. '    except Exception as e:\n'
                .. '        if getattr(args, "progress_file", ""):\n'
                .. '            for cleanup_path in (output_path, re.sub(r"\\.epub$", ".positions.json", output_path)):\n'
                .. '                try:\n                    os.unlink(cleanup_path)\n                except OSError:\n                    pass\n'
                .. '            if "convert_path" in locals() and convert_path != input_path:\n'
                .. '                try:\n                    os.unlink(convert_path)\n                except OSError:\n                    pass\n',
            "cancellation and low-storage handlers"
        )

        result = result:sub(1, function_start - 1) .. fn .. result:sub(function_end)
        result = replaceOnce(
            result,
            '    p_convert.add_argument("--cache-dir", default="")\n',
            '    p_convert.add_argument("--cache-dir", default="")\n'
                .. '    p_convert.add_argument("--progress-file", default="")\n'
                .. '    p_convert.add_argument("--cancel-file", default="")\n'
                .. '    p_convert.add_argument("--min-free-bytes", type=int, default=0)\n',
            "convert command arguments"
        )
        return result
    end)
    if not ok then
        return nil, tostring(patched)
    end

    local backup_path = helper_path .. ".batch-prepare.bak"
    if not readFile(backup_path) then
        local backup_ok, backup_err = writeFile(backup_path, source)
        if not backup_ok then return nil, "Could not create helper backup: " .. tostring(backup_err) end
    end
    local temp_path = helper_path .. ".batch-prepare.tmp"
    local write_ok, write_err = writeFile(temp_path, patched)
    if not write_ok then return nil, "Could not write patched helper: " .. tostring(write_err) end
    local rename_ok, rename_err = os.rename(temp_path, helper_path)
    if not rename_ok then
        os.remove(temp_path)
        return nil, "Could not replace helper: " .. tostring(rename_err)
    end
    return true, "patched"
end

local function patchYJBook()
    local book_path = KINDLE_PLUGIN_DIR .. "/dist/kfxlib/yj_book.py"
    local source = readFile(book_path)
    if not source then return nil, "Could not read " .. book_path end
    if source:find("KOREADER_BATCH_PREPARE_PROGRESS_V1", 1, true) then
        return false, "already_patched"
    end

    -- The upstream v0.0.11 yj_book.py is shipped with CRLF line endings.
    -- Match against normalized text, but retain the exact original bytes in
    -- the .bak file below so uninstall restores the original file unchanged.
    local normalized_source = source:gsub("\r\n", "\n")

    local ok, patched = pcall(function()
        local convert_old = [=[    def convert_to_epub(self, epub2_desired=False, force_cover=False, desaturate_notebooks=False, progress_fn=None):
        from .yj_to_epub import KFX_EPUB
        self.decode_book()
        result = KFX_EPUB(self, epub2_desired=epub2_desired, force_cover=force_cover,
                          desaturate_notebooks=desaturate_notebooks,
                          progress=make_progress(progress_fn)).decompile_to_epub()
        self.final_actions()
        return result
]=]
        local convert_new = [=[    # KOREADER_BATCH_PREPARE_PROGRESS_V1
    def convert_to_epub(self, epub2_desired=False, force_cover=False, desaturate_notebooks=False, progress_fn=None):
        from .yj_to_epub import KFX_EPUB
        if progress_fn is not None:
            self.decode_book(progress_fn=lambda pct: progress_fn(float(pct) * 0.10))
            epub_progress = lambda pct: progress_fn(10.0 + float(pct) * 0.90)
        else:
            self.decode_book()
            epub_progress = None
        result = KFX_EPUB(self, epub2_desired=epub2_desired, force_cover=force_cover,
                          desaturate_notebooks=desaturate_notebooks,
                          progress=make_progress(epub_progress)).decompile_to_epub()
        self.final_actions()
        return result
]=]
        local result = replaceOnce(normalized_source, convert_old, convert_new, "YJ_Book convert_to_epub progress wrapper")

        local decode_start = result:find("    def decode_book(", 1, true)
        local decode_end = result:find("    def locate_book_datafiles(", decode_start, true)
        if not decode_start or not decode_end then error("Could not isolate YJ_Book.decode_book()") end
        local decode_fn = result:sub(decode_start, decode_end - 1)

        decode_fn = replaceOnce(
            decode_fn,
            "                    skip_book_checks=False, skip_dictionary_checks=False):\n",
            "                    skip_book_checks=False, skip_dictionary_checks=False, progress_fn=None):\n",
            "decode_book progress argument"
        )
        decode_fn = replaceOnce(
            decode_fn,
            "            return\n\n        self.locate_book_datafiles()\n\n        missing_container = False\n",
            "            if progress_fn is not None:\n                progress_fn(100)\n            return\n\n        self.locate_book_datafiles()\n"
                .. "        if progress_fn is not None:\n            progress_fn(5)\n\n"
                .. "        missing_container = False\n",
            "decode start progress"
        )
        decode_fn = replaceOnce(
            decode_fn,
            "        missing_container = False\n        for datafile in self.container_datafiles:\n            log.info(\"Processing container: %s\" % datafile.name)\n",
            "        missing_container = False\n"
                .. "        total_datafiles = max(1, len(self.container_datafiles))\n"
                .. "        for datafile_index, datafile in enumerate(self.container_datafiles):\n"
                .. "            if progress_fn is not None:\n"
                .. "                progress_fn(5 + 40.0 * datafile_index / total_datafiles)\n"
                .. "            log.info(\"Processing container: %s\" % datafile.name)\n",
            "container progress start"
        )
        decode_fn = replaceOnce(
            decode_fn,
            "            else:\n                missing_container = True\n\n        if missing_container:\n",
            "            else:\n                missing_container = True\n"
                .. "            if progress_fn is not None:\n"
                .. "                progress_fn(5 + 40.0 * (datafile_index + 1) / total_datafiles)\n\n"
                .. "        if missing_container:\n",
            "container progress end"
        )
        decode_fn = replaceOnce(
            decode_fn,
            "        for container in self.yj_containers:\n            self.fragments.extend(container.get_fragments())\n\n        if not skip_book_checks:\n",
            "        total_containers = max(1, len(self.yj_containers))\n"
                .. "        for container_index, container in enumerate(self.yj_containers):\n"
                .. "            self.fragments.extend(container.get_fragments())\n"
                .. "            if progress_fn is not None:\n"
                .. "                progress_fn(45 + 20.0 * (container_index + 1) / total_containers)\n\n"
                .. "        if progress_fn is not None:\n            progress_fn(70)\n\n"
                .. "        if not skip_book_checks:\n",
            "fragment progress"
        )
        decode_fn = replaceOnce(
            decode_fn,
            "        self.final_actions()\n\n",
            "        if progress_fn is not None:\n            progress_fn(95)\n"
                .. "        self.final_actions()\n"
                .. "        if progress_fn is not None:\n            progress_fn(100)\n\n",
            "decode completion progress"
        )

        return result:sub(1, decode_start - 1) .. decode_fn .. result:sub(decode_end)
    end)
    if not ok then return nil, tostring(patched) end

    local backup_path = book_path .. ".batch-prepare.bak"
    if not readFile(backup_path) then
        local backup_ok, backup_err = writeFile(backup_path, source)
        if not backup_ok then return nil, "Could not back up YJ_Book: " .. tostring(backup_err) end
    end
    local temp_path = book_path .. ".batch-prepare.tmp"
    local write_ok, write_err = writeFile(temp_path, patched)
    if not write_ok then return nil, "Could not write YJ_Book: " .. tostring(write_err) end
    local rename_ok, rename_err = os.rename(temp_path, book_path)
    if not rename_ok then
        os.remove(temp_path)
        return nil, "Could not replace YJ_Book: " .. tostring(rename_err)
    end
    return true, "patched"
end

local function readJson(path)
    local raw = readFile(path)
    if not raw or raw == "" then return nil end
    local ok, value = pcall(json.decode, raw)
    return ok and value or nil
end

local function writeCancel(path)
    writeFile(path, "cancel\n")
end

local function processAlive(pid)
    if not pid then return false end
    local ok, result = pcall(function() return ffi.C.kill(pid, 0) end)
    return ok and result == 0
end

local function signalProcess(pid, signal_number)
    if not pid then return end
    pcall(function() ffi.C.kill(pid, signal_number) end)
end

local function cleanupProgressFiles(progress_path, cancel_path, stdout_path, stderr_path)
    for _, path in ipairs({ progress_path, cancel_path, stdout_path, stderr_path }) do
        if path and path ~= "" then os.remove(path) end
    end
    if progress_path and progress_path ~= "" then
        os.remove(progress_path .. ".tmp")
    end
end

local function cleanupBatchFiles(epub_path, meta_path, progress_path, cancel_path, stdout_path, stderr_path)
    local positions_path = epub_path:gsub("%.epub$", ".positions.json")
    for _, path in ipairs({ epub_path, meta_path, positions_path }) do
        if path and path ~= "" then os.remove(path) end
    end
    -- DRM conversion may create a temporary KFX-ZIP beside the EPUB. The
    -- deterministic prefix lets the parent clean it even after a hard kill.
    local folder = epub_path:match("^(.*)/[^/]+$")
    local basename = epub_path:match("([^/]+)$")
    if folder and basename then
        local prefix = basename .. ".batch-source-"
        pcall(function()
            for name in lfs.dir(folder) do
                if name:sub(1, #prefix) == prefix then
                    os.remove(folder .. "/" .. name)
                end
            end
        end)
    end
    cleanupProgressFiles(progress_path, cancel_path, stdout_path, stderr_path)
end

local function friendlyBytes(bytes)
    if not bytes then return "unknown" end
    local mb = bytes / (1024 * 1024)
    if mb >= 1024 then return string.format("%.1f GB", mb / 1024) end
    return string.format("%.0f MB", mb)
end

function PLUGIN:init()
    self.settings = G_reader_settings:readSetting("kindle_batch_prepare") or {}
    if not self.settings.min_free_mb then self.settings.min_free_mb = DEFAULT_MIN_FREE_MB end

    -- Register the menu before doing any converter setup. This ensures that
    -- setup failures are visible from the KOReader menu instead of making the
    -- plugin silently disappear from Tools.
    logger.info("Kindle batch preparation: registering menu widget")
    self.ui.menu:registerToMainMenu(self)

    local setup_errors = {}
    local helper_patched, patch_message = patchPythonHelper()
    if helper_patched == nil then
        local message = "Kindle helper setup failed: " .. tostring(patch_message)
        table.insert(setup_errors, message)
        logger.warn("Kindle batch preparation:", message)
    end

    local book_patched, book_message = patchYJBook()
    if book_patched == nil then
        local message = "KFX decoding setup failed: " .. tostring(book_message)
        table.insert(setup_errors, message)
        logger.warn("Kindle batch preparation:", message)
    end

    if #setup_errors > 0 then
        self.setup_error = table.concat(setup_errors, "\n\n")
        UIManager:show(InfoMessage:new({
            text = _("Kindle batch preparation registered its menu, but setup needs attention. Open Tools → Kindle batch preparation → Setup status for details.") .. "\n\n" .. self.setup_error,
        }))
        return
    end

    self.setup_error = nil
    if helper_patched or book_patched then
        logger.info("Kindle batch preparation: converter patches applied; restart required")
        UIManager:show(InfoMessage:new({
            text = _("Kindle batch preparation has installed book-level progress, within-book progress, cancellation and low-storage protection.\n\nRestart KOReader to load the updated converter. Original Python files were backed up with .batch-prepare.bak."),
            timeout = 8,
        }))
        UIManager:askForRestart()
        return
    end
end

function PLUGIN:showInfo(text, timeout)
    UIManager:show(InfoMessage:new({ text = text, timeout = timeout }))
end

function PLUGIN:saveSettings()
    G_reader_settings:saveSetting("kindle_batch_prepare", self.settings)
end

function PLUGIN:createReserveMenuItem()
    local choices = { 256, 512, 768, 1024 }
    local submenu = {}
    for _, mb in ipairs(choices) do
        table.insert(submenu, {
            text = T(_("Keep at least %1 MB free"), mb),
            checked_func = function() return self.settings.min_free_mb == mb end,
            callback = function()
                self.settings.min_free_mb = mb
                self:saveSettings()
                self:showInfo(T(_("The batch will stop if free space falls below %1 MB, and it will reserve that space while writing each EPUB."), mb), 4)
            end,
        })
    end
    return {
        text_func = function() return T(_("Low-storage safety reserve (%1 MB)"), self.settings.min_free_mb) end,
        sub_item_table = submenu,
    }
end

function PLUGIN:addToMainMenu(menu_items)
    local sub_items = {}
    if self.setup_error then
        table.insert(sub_items, {
            text = _("Setup status — tap for details"),
            callback = function()
                self:showInfo(_("Batch preparation is disabled until setup is fixed:\n\n") .. tostring(self.setup_error))
            end,
        })
    else
        table.insert(sub_items, {
            text = _("Prepare all Kindle books for KOReader"),
            help_text = _("Convert all locally available Kindle KFX books one after another. Existing prepared books are skipped. Tap the progress message to pause, then choose Abort to stop the current book and the whole batch."),
            callback = function()
                if self.setup_error then
                    self:showInfo(_("Batch preparation is disabled until setup is fixed:\n\n") .. tostring(self.setup_error))
                    return
                end
                self:prepareAllBooks()
            end,
        })
        table.insert(sub_items, self:createReserveMenuItem())
    end

    menu_items.kindle_batch_prepare = {
        text = _("Kindle batch preparation"),
        sorting_hint = "tools",
        separator = true,
        sub_item_table = sub_items,
    }
end

function PLUGIN:buildRuntime()
    local settings = G_reader_settings:readSetting("kindle_plugin") or {}
    if not settings.cache_dir then
        settings.cache_dir = DataStorage:getFullDataDir() .. "/cache/kindle.koplugin"
    end
    local helper = HelperClient:new()
    helper:setSettings(settings)
    local index = LibraryIndex:new()
    index:setSettings(settings)
    local virtual = VirtualLibrary:new(index)
    local cache = CacheManager:new(helper)
    virtual:setCacheManager(cache)
    virtual:setSettings(settings)
    cache:setSettings(settings)
    return helper, virtual, cache, settings
end

function PLUGIN:convertWithProgress(helper, cache, settings, book, book_number, book_total)
    local epub_path, meta_path = cache:getCachePaths(book)
    local cache_ok, cache_err = cache:ensureCacheDir()
    if not cache_ok then return nil, { code = "cache_error", message = tostring(cache_err) } end

    local temp_base = os.tmpname()
    os.remove(temp_base)
    local progress_path = temp_base .. ".progress.json"
    local cancel_path = temp_base .. ".cancel"
    local stdout_path = temp_base .. ".stdout"
    local stderr_path = temp_base .. ".stderr"
    local min_free_bytes = (tonumber(self.settings.min_free_mb) or DEFAULT_MIN_FREE_MB) * 1024 * 1024

    local args = {
        helper:getBinaryPath(), "convert",
        "--input", book.source_path,
        "--output", epub_path,
        "--cache-dir", settings.cache_dir,
        "--progress-file", progress_path,
        "--cancel-file", cancel_path,
        "--min-free-bytes", tostring(min_free_bytes),
    }
    local command = util.shell_escape(args)
        .. " > " .. util.shell_escape({ stdout_path })
        .. " 2> " .. util.shell_escape({ stderr_path })
        .. " & echo $!"
    local launcher = io.popen(command, "r")
    if not launcher then
        cleanupBatchFiles(epub_path, meta_path, progress_path, cancel_path, stdout_path, stderr_path)
        return nil, { code = "spawn_error", message = "Could not start kindle-helper" }
    end
    local pid = tonumber(launcher:read("*l"))
    launcher:close()
    if not pid then
        cleanupBatchFiles(epub_path, meta_path, progress_path, cancel_path, stdout_path, stderr_path)
        return nil, { code = "spawn_error", message = "Could not obtain conversion process ID" }
    end

    local title = book.display_name or book.title or book.id
    local progress_text = T(_("Preparing book %1 of %2\n%3\nStarting conversion…\nTap here to pause / abort"), book_number, book_total, title)
    local aborted = false
    Trapper:setPausedText(
        T(_("Stop preparing this book and all remaining books?\n\nThe current incomplete EPUB will be discarded. Books already prepared will be kept.")),
        _("Abort batch"),
        _("Continue")
    )

    while processAlive(pid) do
        local state = readJson(progress_path)
        if state then
            local pct = tonumber(state.percent) or 0
            local filled = math.max(0, math.min(20, math.floor(pct / 5)))
            local bar = string.rep("#", filled) .. string.rep("-", 20 - filled)
            progress_text = string.format(
                "Preparing book %d of %d\n%s\n[%s] %.0f%%\n%s\nFree storage: %s\nTap here to pause / abort",
                book_number, book_total, title, bar, pct,
                tostring(state.stage or "Converting"), friendlyBytes(state.free_bytes)
            )
        end
        if not Trapper:info(progress_text) then
            aborted = true
            writeCancel(cancel_path)
            signalProcess(pid, 15)
            break
        end
        ffiUtil.sleep(0.15)
    end

    if aborted then
        local started = os.time()
        while processAlive(pid) and os.time() - started < 12 do
            ffiUtil.sleep(0.15)
        end
        if processAlive(pid) then
            signalProcess(pid, 9)
            ffiUtil.sleep(0.3)
        end
        cleanupBatchFiles(epub_path, meta_path, progress_path, cancel_path, stdout_path, stderr_path)
        return nil, { code = "cancelled", message = "Batch aborted by user" }
    end

    local raw = readFile(stdout_path) or ""
    local ok, result = pcall(json.decode, raw)
    local stderr = readFile(stderr_path) or ""
    cleanupProgressFiles(progress_path, cancel_path, stdout_path, stderr_path)
    if not ok or type(result) ~= "table" then
        cleanupBatchFiles(epub_path, meta_path, "", "", "", "")
        return nil, { code = "invalid_result", message = "kindle-helper returned invalid JSON. " .. stderr:sub(1, 500) }
    end
    if result.ok ~= true then
        cleanupBatchFiles(epub_path, meta_path, "", "", "", "")
    end
    return result
end

function PLUGIN:prepareOneBook(helper, cache, settings, book, index, total)
    local fresh, epub_path, meta_path = cache:isFresh(book)
    if fresh then return "cached" end

    local result, err = self:convertWithProgress(helper, cache, settings, book, index, total)
    if not result then return nil, err end

    if not result.ok and result.code == "drm" then
        Trapper:info(T(_("Book %1 of %2\n%3\nExtracting its access key…"), index, total, book.display_name or book.title))
        local key_result, key_err = helper:extractBookKey(book.source_path)
        if key_result and key_result.ok then
            result, err = self:convertWithProgress(helper, cache, settings, book, index, total)
            if not result then return nil, err end
        else
            return nil, { code = "drm_key", message = (key_result and key_result.message) or key_err or "Could not extract book key" }
        end
    end

    if not result.ok then
        if result.code == "cancelled" then return nil, result end
        if result.code == "low_storage" then return nil, result end
        return nil, result
    end

    local wrote, write_err = cache:writeMetadata(meta_path, book)
    if not wrote then
        cache:clearBookCache(book)
        return nil, { code = "cache_metadata", message = tostring(write_err) }
    end
    local now_fresh = cache:isFresh(book)
    if not now_fresh then
        cache:clearBookCache(book)
        return nil, { code = "cache_validation", message = "The EPUB was created but did not pass the cache-integrity check." }
    end
    return "prepared"
end

function PLUGIN:prepareAllBooks()
    local helper, virtual, cache, settings = self:buildRuntime()
    Trapper:wrap(function()
        Trapper:setPausedText(
            _("Stop the entire preparation job? The current incomplete book will be discarded; already prepared books will be kept."),
            _("Abort batch"), _("Continue")
        )
        local books, err = virtual:refresh(true)
        if not books then
            Trapper:clear()
            self:showInfo(_("Could not read the Kindle library:\n") .. tostring(err))
            return
        end

        local convertible = {}
        local direct_count = 0
        local unavailable_count = 0
        local cached_count = 0
        for _, book in ipairs(books) do
            if book.open_mode == "convert" and book.source_path then
                table.insert(convertible, book)
            elseif book.open_mode == "direct" then
                direct_count = direct_count + 1
            else
                unavailable_count = unavailable_count + 1
            end
        end

        if #convertible == 0 then
            Trapper:clear()
            self:showInfo(T(_("No locally available KFX books need conversion.\n\nNative-format books: %1\nUnavailable or unsupported: %2"), direct_count, unavailable_count))
            return
        end

        local prepared_count, failed_count = 0, 0
        local stop_reason = nil
        local aborted = false
        for index, book in ipairs(convertible) do
            local fresh = cache:isFresh(book)
            if fresh then
                cached_count = cached_count + 1
                local message = T(_("Book %1 of %2\n%3\nAlready prepared — skipping.\nTap here to pause / abort"), index, #convertible, book.display_name or book.title)
                if not Trapper:info(message) then
                    aborted = true
                    break
                end
            else
                local status, result = self:prepareOneBook(helper, cache, settings, book, index, #convertible)
                if status == "prepared" then
                    prepared_count = prepared_count + 1
                elseif status == "cached" then
                    cached_count = cached_count + 1
                else
                    local code = result and result.code or "unknown"
                    if code == "cancelled" then
                        aborted = true
                        break
                    elseif code == "low_storage" then
                        stop_reason = result.message or _("The low-storage safety reserve was reached.")
                        break
                    else
                        failed_count = failed_count + 1
                        logger.warn("Kindle batch preparation failed for", book.title, code, result and result.message or "")
                    end
                end
            end
        end

        Trapper:clear()
        local summary = string.format(
            "Kindle batch preparation finished\n\nNewly prepared: %d\nAlready prepared: %d\nNative-format books (no conversion needed): %d\nUnavailable/unsupported: %d\nFailed: %d",
            prepared_count, cached_count, direct_count, unavailable_count, failed_count
        )
        if aborted then
            summary = summary .. "\n\nStopped by you. Completed EPUBs have been kept."
        elseif stop_reason then
            summary = summary .. "\n\nStopped automatically to protect free storage:\n" .. tostring(stop_reason)
        else
            summary = summary .. "\n\nAll eligible books have been checked."
        end
        self:showInfo(summary)
    end)
end

return PLUGIN
